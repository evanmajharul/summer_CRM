<?php
require 'config.php'; require_login();
$period=$_GET['period']??'week';
if(!in_array($period,['day','week','all'],true))$period='week';
$shiftWhere=$period==='day'?'WHERE DATE(s.start_at)=CURDATE()':($period==='week'?'WHERE YEARWEEK(s.start_at,1)=YEARWEEK(CURDATE(),1)':'');
$tot=$pdo->query("SELECT COUNT(DISTINCT s.staff_id) people,COALESCE(SUM(TIMESTAMPDIFF(MINUTE,s.start_at,s.end_at)/60),0) hours,COALESCE(SUM((TIMESTAMPDIFF(MINUTE,s.start_at,s.end_at)/60)*s.hourly_rate),0) gross FROM shifts s $shiftWhere")->fetch();
$payWhere=$period==='day'?'WHERE payment_date=CURDATE()':($period==='week'?'WHERE YEARWEEK(payment_date,1)=YEARWEEK(CURDATE(),1)':'');
$paid=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments $payWhere")->fetchColumn();
$cats=$pdo->query("SELECT category,COUNT(*) shifts,ROUND(SUM(TIMESTAMPDIFF(MINUTE,start_at,end_at)/60),2) hours,ROUND(SUM((TIMESTAMPDIFF(MINUTE,start_at,end_at)/60)*hourly_rate),2) earnings FROM shifts s $shiftWhere GROUP BY category")->fetchAll();
$people=$pdo->query("SELECT st.full_name,
ROUND(COALESCE((SELECT SUM((TIMESTAMPDIFF(MINUTE,s.start_at,s.end_at)/60)*s.hourly_rate) FROM shifts s WHERE s.staff_id=st.id),0),2) gross,
ROUND(COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.staff_id=st.id),0),2) paid
FROM staff st ORDER BY st.full_name")->fetchAll();
$title='Dashboard'; include 'header.php';
?>
<div class="d-flex justify-content-between flex-wrap gap-2 mb-4"><div><h1 class="h3">Dashboard</h1><p class="text-secondary">Hours, earnings and payments overview.</p></div>
<div class="btn-group align-self-start"><a class="btn btn-outline-primary <?=$period==='day'?'active':''?>" href="?period=day">Daily</a><a class="btn btn-outline-primary <?=$period==='week'?'active':''?>" href="?period=week">Weekly</a><a class="btn btn-outline-primary <?=$period==='all'?'active':''?>" href="?period=all">All time</a></div></div>
<div class="row g-3 mb-4">
<?php foreach([['Staff',(int)$tot['people']],['Hours',number_format((float)$tot['hours'],2)],['Gross','£'.number_format((float)$tot['gross'],2)],['Payments','£'.number_format($paid,2)]] as $x): ?>
<div class="col-sm-6 col-xl-3"><div class="stat"><span><?=e($x[0])?></span><strong><?=e($x[1])?></strong></div></div><?php endforeach; ?></div>
<div class="row g-4"><div class="col-lg-5"><div class="card shadow-sm"><div class="card-header fw-semibold">Category summary</div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Category</th><th>Shifts</th><th>Hours</th><th>Earnings</th></tr></thead><tbody>
<?php foreach($cats as $c): ?><tr><td><?=e(ucwords(str_replace('_',' ',$c['category'])))?></td><td><?=$c['shifts']?></td><td><?=$c['hours']?></td><td>£<?=number_format((float)$c['earnings'],2)?></td></tr><?php endforeach; ?>
<?php if(!$cats): ?><tr><td colspan="4" class="text-center text-secondary py-4">No shifts.</td></tr><?php endif; ?></tbody></table></div></div></div>
<div class="col-lg-7"><div class="card shadow-sm"><div class="card-header fw-semibold">Individual balances</div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Staff</th><th>Total earned</th><th>Total paid</th><th>Outstanding</th></tr></thead><tbody>
<?php foreach($people as $p): $bal=max(0,(float)$p['gross']-(float)$p['paid']); ?><tr><td><?=e($p['full_name'])?></td><td>£<?=number_format((float)$p['gross'],2)?></td><td>£<?=number_format((float)$p['paid'],2)?></td><td class="fw-bold">£<?=number_format($bal,2)?></td></tr><?php endforeach; ?>
</tbody></table></div></div></div></div>
<?php include 'footer.php'; ?>
