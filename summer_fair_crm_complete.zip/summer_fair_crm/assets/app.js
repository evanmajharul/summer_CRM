document.querySelectorAll('form.confirm').forEach(f=>f.addEventListener('submit',e=>{if(!confirm('Are you sure?'))e.preventDefault()}));
const s=document.getElementById('staffSelect'),r=document.getElementById('rate');
if(s&&r)s.addEventListener('change',()=>{const o=s.options[s.selectedIndex];if(o.dataset.rate&&!r.value)r.value=o.dataset.rate});
