# Summer Fair Payment Dashboard CRM

## Installation on XAMPP
1. Copy the `summer_fair_crm` folder into `htdocs`.
2. Start Apache and MySQL.
3. Open phpMyAdmin and import `database.sql`.
4. Visit `http://localhost/summer_fair_crm/`.

## Installation on a live server
1. Upload the folder to `public_html` or a subfolder.
2. Create a MySQL database and database user.
3. Import `database.sql`.
4. Open `config.php` and change:
   - `DB_HOST`
   - `DB_NAME`
   - `DB_USER`
   - `DB_PASS`
5. Use PHP 8.1 or newer and enable HTTPS.
6. Sign in and change the initial passwords through Accounts.
7. Delete or protect `database.sql` after importing it.

## Included features
- Primary admin, admin and viewer permissions
- Staff and hourly-rate management
- Three work categories
- Shift scheduling with automatic earnings
- Daily, weekly and all-time dashboard views
- Payment records and outstanding balances
- Primary-admin-only audit log
- Secure password hashing, prepared SQL and CSRF protection
