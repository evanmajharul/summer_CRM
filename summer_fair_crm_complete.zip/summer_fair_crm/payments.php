<?php
require 'config.php';require_login();
if($_SERVER['REQUEST_METHOD']==='POST'){
 require_manager();check_csrf();$a=$_POST['action']??'';
 if($a==='save'){
  $id=(int)($_POST['id']??0);$staff=(int)$_POST['staff_id'];$amount=(float)$_POST['amount'];$date=$_POST['payment_date'];$note=trim($_POST['note']??'');
  if(!$staff||$amount<=0){flash('danger','Enter a valid payment.');go('payments.php');}
  if($id){$pdo->prepare('UPDATE payments SET staff_id=?,amount=?,payment_date=?,note=?,updated_by=? WHERE id=?')->execute([$staff,$amount,$date,$note,user()['id'],$id]);audit($pdo,'UPDATE','payment',$id,"Updated payment £$amount");}
  else{$pdo->prepare('INSERT INTO payments(staff_id,amount,payment_date,note,created_by,updated_by) VALUES(?,?,?,?,?,?)')->execute([$staff,$amount,$date,$note,user()['id'],user()['id']]);$id=(int)$pdo->lastInsertId();audit($pdo,'CREATE','payment',$id,"Payment £$amount");}
  flash('success','Payment saved and deducted from outstanding balance.');go('payments.php');
 }
 if($a==='delete'){$id=(int)$_POST['id'];$pdo->prepare('DELETE FROM payments WHERE id=?')->execute([$id]);audit($pdo,'DELETE','payment',$id,'Deleted payment');go('payments.php');}
}
$edit=null;if(!empty($_GET['edit'])&&can_manage()){$q=$pdo->prepare('SELECT * FROM payments WHERE id=?');$q->execute([(int)$_GET['edit']]);$edit=$q->fetch();}
$staff=$pdo->query('SELECT st.id,st.full_name,COALESCE((SELECT SUM((TIMESTAMPDIFF(MINUTE,s.start_at,s.end_at)/60)*s.hourly_rate) FROM shifts s WHERE s.staff_id=st.id),0) gross,COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.staff_id=st.id),0) paid FROM staff st ORDER BY st.full_name')->fetchAll();
$list=$pdo->query('SELECT p.*,st.full_name,u.username creator FROM payments p JOIN staff st ON st.id=p.staff_id LEFT JOIN system_users u ON u.id=p.created_by ORDER BY payment_date DESC,id DESC')->fetchAll();
$title='Payments';include 'header.php';
?>
<div class="row g-4"><?php if(can_manage()):?><div class="col-xl-4"><div class="card shadow-sm"><div class="card-header fw-semibold"><?=$edit?'Edit':'Record'?> payment</div><div class="card-body"><form method="post">
<input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=(int)($edit['id']??0)?>">
<div class="mb-3"><label class="form-label">Staff</label><select class="form-select" name="staff_id" required><option value="">Choose</option><?php foreach($staff as $s):$b=max(0,$s['gross']-$s['paid']);?><option value="<?=$s['id']?>" <?=(int)($edit['staff_id']??0)===(int)$s['id']?'selected':''?>><?=e($s['full_name'])?> — £<?=number_format($b,2)?> due</option><?php endforeach;?></select></div>
<div class="mb-3"><label class="form-label">Amount (£)</label><input class="form-control" type="number" min=".01" step=".01" name="amount" required value="<?=e($edit['amount']??'')?>"></div>
<div class="mb-3"><label class="form-label">Date</label><input class="form-control" type="date" name="payment_date" required value="<?=e($edit['payment_date']??date('Y-m-d'))?>"></div>
<div class="mb-3"><label class="form-label">Note</label><textarea class="form-control" name="note"><?=e($edit['note']??'')?></textarea></div><button class="btn btn-primary">Save</button></form></div></div></div><?php endif;?>
<div class="<?=can_manage()?'col-xl-8':'col-12'?>"><div class="card shadow-sm"><div class="card-header fw-semibold">Payment history</div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Staff</th><th>Amount</th><th>Date</th><th>Note</th><?php if(primary()):?><th>Added by</th><?php endif;?><?php if(can_manage()):?><th>Actions</th><?php endif;?></tr></thead><tbody>
<?php foreach($list as $r):?><tr><td><?=e($r['full_name'])?></td><td>£<?=number_format((float)$r['amount'],2)?></td><td><?=e($r['payment_date'])?></td><td><?=e($r['note'])?></td><?php if(primary()):?><td><?=e($r['creator'])?></td><?php endif;?><?php if(can_manage()):?><td><a class="btn btn-sm btn-outline-primary" href="?edit=<?=$r['id']?>">Edit</a><form method="post" class="d-inline confirm"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn btn-sm btn-outline-danger">Delete</button></form></td><?php endif;?></tr><?php endforeach;?></tbody></table></div></div></div></div>
<?php include 'footer.php'; ?>
