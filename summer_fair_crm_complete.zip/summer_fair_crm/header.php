<?php require_once __DIR__.'/config.php'; require_login(); $title=$title??'Summer Fair CRM'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($title)?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
<div class="container-fluid">
<a class="navbar-brand fw-bold" href="dashboard.php">Summer Fair CRM</a>
<button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav"><span class="navbar-toggler-icon"></span></button>
<div class="collapse navbar-collapse" id="nav">
<ul class="navbar-nav me-auto">
<li><a class="nav-link" href="dashboard.php">Dashboard</a></li>
<li><a class="nav-link" href="staff.php">Staff</a></li>
<li><a class="nav-link" href="shifts.php">Shifts</a></li>
<li><a class="nav-link" href="payments.php">Payments</a></li>
<?php if(primary()): ?><li><a class="nav-link" href="accounts.php">Accounts</a></li><li><a class="nav-link" href="audit.php">Audit Log</a></li><?php endif; ?>
</ul>
<span class="navbar-text me-3"><?=e(user()['username'])?> · <?=e(str_replace('_',' ',user()['role']))?></span>
<a class="btn btn-light btn-sm" href="logout.php">Logout</a>
</div></div></nav>
<main class="container-fluid py-4">
<?php if(!empty($_SESSION['flash'])): $f=$_SESSION['flash']; unset($_SESSION['flash']); ?>
<div class="alert alert-<?=e($f['type'])?> alert-dismissible fade show"><?=e($f['message'])?><button class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>
