<?php
require 'config.php';
if(logged_in()) go('dashboard.php');
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    check_csrf();
    $q=$pdo->prepare('SELECT * FROM system_users WHERE username=? AND active=1 LIMIT 1');
    $q->execute([trim($_POST['username']??'')]);
    $u=$q->fetch();
    if($u && password_verify($_POST['password']??'', $u['password_hash'])){
        session_regenerate_id(true);
        $_SESSION['user']=['id'=>(int)$u['id'],'username'=>$u['username'],'role'=>$u['role']];
        $pdo->prepare('UPDATE system_users SET last_login=NOW() WHERE id=?')->execute([$u['id']]);
        go('dashboard.php');
    }
    $error='Invalid username or password.';
}
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Login</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="assets/style.css" rel="stylesheet"></head>
<body class="login-bg"><div class="container"><div class="row min-vh-100 align-items-center justify-content-center"><div class="col-md-5 col-lg-4">
<div class="card shadow-lg border-0"><div class="card-body p-4"><h1 class="h3 text-center fw-bold">Summer Fair CRM</h1><p class="text-center text-secondary">Payment and workforce dashboard</p>
<?php if($error): ?><div class="alert alert-danger"><?=e($error)?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?=e(csrf())?>">
<div class="mb-3"><label class="form-label">Username</label><input class="form-control" name="username" required autofocus></div>
<div class="mb-3"><label class="form-label">Password</label><input class="form-control" type="password" name="password" required></div>
<button class="btn btn-primary w-100">Sign in</button></form></div></div></div></div></div></body></html>
