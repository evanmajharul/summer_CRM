<?php
require 'config.php';require_primary();
if($_SERVER['REQUEST_METHOD']==='POST'){
 check_csrf();$a=$_POST['action']??'';
 if($a==='save'){
  $id=(int)($_POST['id']??0);$name=trim($_POST['username']);$role=$_POST['role'];$pass=$_POST['password']??'';
  if(!in_array($role,['primary_admin','admin','viewer'],true)||$name===''){flash('danger','Invalid account.');go('accounts.php');}
  if($id){if($pass!==''){$pdo->prepare('UPDATE system_users SET username=?,role=?,password_hash=? WHERE id=?')->execute([$name,$role,password_hash($pass,PASSWORD_DEFAULT),$id]);}else{$pdo->prepare('UPDATE system_users SET username=?,role=? WHERE id=?')->execute([$name,$role,$id]);}audit($pdo,'UPDATE','account',$id,"Updated $name");}
  else{if(strlen($pass)<8){flash('danger','Password must have at least 8 characters.');go('accounts.php');}$pdo->prepare('INSERT INTO system_users(username,password_hash,role) VALUES(?,?,?)')->execute([$name,password_hash($pass,PASSWORD_DEFAULT),$role]);audit($pdo,'CREATE','account',(int)$pdo->lastInsertId(),"Created $name");}
  flash('success','Account saved.');go('accounts.php');
 }
}
$edit=null;if(!empty($_GET['edit'])){$q=$pdo->prepare('SELECT id,username,role FROM system_users WHERE id=?');$q->execute([(int)$_GET['edit']]);$edit=$q->fetch();}
$list=$pdo->query('SELECT id,username,role,active,last_login FROM system_users ORDER BY id')->fetchAll();$title='Accounts';include 'header.php';
?>
<div class="row g-4"><div class="col-lg-4"><div class="card shadow-sm"><div class="card-header fw-semibold"><?=$edit?'Edit':'Create'?> account</div><div class="card-body"><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=(int)($edit['id']??0)?>">
<div class="mb-3"><label class="form-label">Username</label><input class="form-control" name="username" required value="<?=e($edit['username']??'')?>"></div><div class="mb-3"><label class="form-label">Role</label><select class="form-select" name="role"><option value="admin">Admin</option><option value="viewer" <?=($edit['role']??'')==='viewer'?'selected':''?>>Viewer</option><option value="primary_admin" <?=($edit['role']??'')==='primary_admin'?'selected':''?>>Primary admin</option></select></div><div class="mb-3"><label class="form-label">Password <?=$edit?'(blank keeps current)':''?></label><input class="form-control" type="password" name="password" <?=$edit?'':'required'?>></div><button class="btn btn-primary">Save</button></form></div></div></div>
<div class="col-lg-8"><div class="card shadow-sm"><div class="card-header fw-semibold">Accounts</div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Username</th><th>Role</th><th>Status</th><th>Last login</th><th></th></tr></thead><tbody><?php foreach($list as $r):?><tr><td><?=e($r['username'])?></td><td><?=e(str_replace('_',' ',$r['role']))?></td><td><?=$r['active']?'Active':'Disabled'?></td><td><?=e($r['last_login']??'Never')?></td><td><a class="btn btn-sm btn-outline-primary" href="?edit=<?=$r['id']?>">Edit</a></td></tr><?php endforeach;?></tbody></table></div></div></div></div>
<?php include 'footer.php'; ?>
