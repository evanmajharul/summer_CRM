<?php
declare(strict_types=1);
session_start();

const DB_HOST = 'localhost';
const DB_NAME = 'summer_fair_crm';
const DB_USER = 'root';
const DB_PASS = '';

try {
    $pdo = new PDO(
        'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database connection failed. Check config.php and import database.sql.');
}

function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function go(string $url): never { header('Location: '.$url); exit; }
function user(): array { return $_SESSION['user'] ?? []; }
function logged_in(): bool { return !empty($_SESSION['user']); }
function can_manage(): bool { return in_array(user()['role'] ?? '', ['primary_admin','admin'], true); }
function primary(): bool { return (user()['role'] ?? '') === 'primary_admin'; }
function require_login(): void { if (!logged_in()) go('login.php'); }
function require_manager(): void { require_login(); if (!can_manage()) { http_response_code(403); exit('Access denied'); } }
function require_primary(): void { require_login(); if (!primary()) { http_response_code(403); exit('Access denied'); } }

function csrf(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function check_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        exit('Invalid request token.');
    }
}
function flash(string $type, string $message): void {
    $_SESSION['flash'] = compact('type','message');
}
function audit(PDO $pdo, string $action, string $entity, ?int $entityId, string $details=''): void {
    if (!can_manage()) return;
    $q = $pdo->prepare('INSERT INTO audit_logs(admin_id,action,entity_type,entity_id,details,ip_address) VALUES(?,?,?,?,?,?)');
    $q->execute([user()['id'],$action,$entity,$entityId,$details,$_SERVER['REMOTE_ADDR'] ?? null]);
}
