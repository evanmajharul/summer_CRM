<?php
require 'config.php'; require_login();
if($_SERVER['REQUEST_METHOD']==='POST'){
    require_manager(); check_csrf(); $a=$_POST['action']??'';
    if($a==='save'){
        $id=(int)($_POST['id']??0); $name=trim($_POST['full_name']??''); $phone=trim($_POST['phone']??''); $rate=(float)($_POST['hourly_rate']??0);
        if($name===''||$rate<0){flash('danger','Enter valid staff details.');go('staff.php');}
        if($id){$pdo->prepare('UPDATE staff SET full_name=?,phone=?,hourly_rate=?,updated_by=? WHERE id=?')->execute([$name,$phone,$rate,user()['id'],$id]);audit($pdo,'UPDATE','staff',$id,"Updated $name");}
        else{$pdo->prepare('INSERT INTO staff(full_name,phone,hourly_rate,created_by,updated_by) VALUES(?,?,?,?,?)')->execute([$name,$phone,$rate,user()['id'],user()['id']]);$id=(int)$pdo->lastInsertId();audit($pdo,'CREATE','staff',$id,"Added $name");}
        flash('success','Staff record saved.');go('staff.php');
    }
    if($a==='delete'){$id=(int)$_POST['id'];$pdo->prepare('DELETE FROM staff WHERE id=?')->execute([$id]);audit($pdo,'DELETE','staff',$id,'Deleted staff');flash('success','Staff deleted.');go('staff.php');}
}
$edit=null;if(!empty($_GET['edit'])&&can_manage()){$q=$pdo->prepare('SELECT * FROM staff WHERE id=?');$q->execute([(int)$_GET['edit']]);$edit=$q->fetch();}
$list=$pdo->query('SELECT st.*,u.username creator FROM staff st LEFT JOIN system_users u ON u.id=st.created_by ORDER BY st.full_name')->fetchAll();
$title='Staff';include 'header.php';
?>
<div class="row g-4"><?php if(can_manage()): ?><div class="col-lg-4"><div class="card shadow-sm"><div class="card-header fw-semibold"><?=$edit?'Edit':'Add'?> staff</div><div class="card-body"><form method="post">
<input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=(int)($edit['id']??0)?>">
<div class="mb-3"><label class="form-label">Full name</label><input class="form-control" name="full_name" required value="<?=e($edit['full_name']??'')?>"></div>
<div class="mb-3"><label class="form-label">Phone</label><input class="form-control" name="phone" value="<?=e($edit['phone']??'')?>"></div>
<div class="mb-3"><label class="form-label">Hourly rate (£)</label><input class="form-control" type="number" min="0" step=".01" name="hourly_rate" required value="<?=e($edit['hourly_rate']??'')?>"></div>
<button class="btn btn-primary">Save</button><?php if($edit):?><a class="btn btn-outline-secondary" href="staff.php">Cancel</a><?php endif;?></form></div></div></div><?php endif;?>
<div class="<?=can_manage()?'col-lg-8':'col-12'?>"><div class="card shadow-sm"><div class="card-header fw-semibold">Staff list</div><div class="table-responsive"><table class="table mb-0"><thead><tr><th>Name</th><th>Phone</th><th>Rate</th><?php if(primary()):?><th>Added by</th><th>Created</th><?php endif;?><?php if(can_manage()):?><th>Actions</th><?php endif;?></tr></thead><tbody>
<?php foreach($list as $r):?><tr><td><?=e($r['full_name'])?></td><td><?=e($r['phone'])?></td><td>£<?=number_format((float)$r['hourly_rate'],2)?></td><?php if(primary()):?><td><?=e($r['creator'])?></td><td><?=e($r['created_at'])?></td><?php endif;?><?php if(can_manage()):?><td><a class="btn btn-sm btn-outline-primary" href="?edit=<?=$r['id']?>">Edit</a><form class="d-inline confirm" method="post"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn btn-sm btn-outline-danger">Delete</button></form></td><?php endif;?></tr><?php endforeach;?></tbody></table></div></div></div></div>
<?php include 'footer.php'; ?>
