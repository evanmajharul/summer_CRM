<?php
require 'config.php';require_login();
$cats=['toyride'=>'Toy Ride','children_car'=>'Children Car','juice_slush_shop'=>'Juice / Slush Shop'];
if($_SERVER['REQUEST_METHOD']==='POST'){
 require_manager();check_csrf();$a=$_POST['action']??'';
 if($a==='save'){
  $id=(int)($_POST['id']??0);$staff=(int)$_POST['staff_id'];$cat=$_POST['category'];$start=str_replace('T',' ',$_POST['start_at']);$end=str_replace('T',' ',$_POST['end_at']);$rate=(float)$_POST['hourly_rate'];
  if(!$staff||!isset($cats[$cat])||strtotime($end)<=strtotime($start)){flash('danger','Enter valid shift details.');go('shifts.php');}
  if($id){$pdo->prepare('UPDATE shifts SET staff_id=?,category=?,start_at=?,end_at=?,hourly_rate=?,updated_by=? WHERE id=?')->execute([$staff,$cat,$start,$end,$rate,user()['id'],$id]);audit($pdo,'UPDATE','shift',$id,'Updated shift');}
  else{$pdo->prepare('INSERT INTO shifts(staff_id,category,start_at,end_at,hourly_rate,created_by,updated_by) VALUES(?,?,?,?,?,?,?)')->execute([$staff,$cat,$start,$end,$rate,user()['id'],user()['id']]);$id=(int)$pdo->lastInsertId();audit($pdo,'CREATE','shift',$id,'Added shift');}
  flash('success','Shift saved.');go('shifts.php');
 }
 if($a==='delete'){$id=(int)$_POST['id'];$pdo->prepare('DELETE FROM shifts WHERE id=?')->execute([$id]);audit($pdo,'DELETE','shift',$id,'Deleted shift');go('shifts.php');}
}
$edit=null;if(!empty($_GET['edit'])&&can_manage()){$q=$pdo->prepare('SELECT * FROM shifts WHERE id=?');$q->execute([(int)$_GET['edit']]);$edit=$q->fetch();}
$staff=$pdo->query('SELECT id,full_name,hourly_rate FROM staff ORDER BY full_name')->fetchAll();
$fc=$_GET['category']??'';$fd=$_GET['date']??'';$sql='SELECT s.*,st.full_name,u.username creator,ROUND(TIMESTAMPDIFF(MINUTE,s.start_at,s.end_at)/60,2) hours,ROUND((TIMESTAMPDIFF(MINUTE,s.start_at,s.end_at)/60)*s.hourly_rate,2) earnings FROM shifts s JOIN staff st ON st.id=s.staff_id LEFT JOIN system_users u ON u.id=s.created_by WHERE 1';$par=[];
if(isset($cats[$fc])){$sql.=' AND s.category=?';$par[]=$fc;}if($fd){$sql.=' AND DATE(s.start_at)=?';$par[]=$fd;}$sql.=' ORDER BY s.start_at DESC';$q=$pdo->prepare($sql);$q->execute($par);$list=$q->fetchAll();
$title='Shifts';include 'header.php';
?>
<div class="row g-4"><?php if(can_manage()):?><div class="col-xl-4"><div class="card shadow-sm"><div class="card-header fw-semibold"><?=$edit?'Edit':'Add'?> shift</div><div class="card-body"><form method="post">
<input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=(int)($edit['id']??0)?>">
<div class="mb-3"><label class="form-label">Staff</label><select class="form-select" name="staff_id" id="staffSelect" required><option value="">Choose</option><?php foreach($staff as $s):?><option value="<?=$s['id']?>" data-rate="<?=$s['hourly_rate']?>" <?=(int)($edit['staff_id']??0)===(int)$s['id']?'selected':''?>><?=e($s['full_name'])?></option><?php endforeach;?></select></div>
<div class="mb-3"><label class="form-label">Category</label><select class="form-select" name="category"><?php foreach($cats as $k=>$v):?><option value="<?=$k?>" <?=($edit['category']??'')===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select></div>
<div class="mb-3"><label class="form-label">Start</label><input class="form-control" type="datetime-local" name="start_at" required value="<?=!empty($edit['start_at'])?date('Y-m-d\TH:i',strtotime($edit['start_at'])):''?>"></div>
<div class="mb-3"><label class="form-label">End</label><input class="form-control" type="datetime-local" name="end_at" required value="<?=!empty($edit['end_at'])?date('Y-m-d\TH:i',strtotime($edit['end_at'])):''?>"></div>
<div class="mb-3"><label class="form-label">Hourly rate (£)</label><input id="rate" class="form-control" type="number" min="0" step=".01" name="hourly_rate" required value="<?=e($edit['hourly_rate']??'')?>"></div>
<button class="btn btn-primary">Save</button></form></div></div></div><?php endif;?>
<div class="<?=can_manage()?'col-xl-8':'col-12'?>"><div class="card shadow-sm"><div class="card-header"><form class="row g-2"><div class="col-md-5"><select class="form-select" name="category"><option value="">All categories</option><?php foreach($cats as $k=>$v):?><option value="<?=$k?>" <?=$fc===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select></div><div class="col-md-4"><input class="form-control" type="date" name="date" value="<?=e($fd)?>"></div><div class="col-md-3"><button class="btn btn-outline-primary w-100">Filter</button></div></form></div>
<div class="table-responsive"><table class="table mb-0"><thead><tr><th>Staff</th><th>Category</th><th>Start</th><th>End</th><th>Hours</th><th>Earnings</th><?php if(primary()):?><th>Added by</th><?php endif;?><?php if(can_manage()):?><th>Actions</th><?php endif;?></tr></thead><tbody>
<?php foreach($list as $r):?><tr><td><?=e($r['full_name'])?></td><td><?=e($cats[$r['category']])?></td><td><?=e($r['start_at'])?></td><td><?=e($r['end_at'])?></td><td><?=$r['hours']?></td><td>£<?=number_format((float)$r['earnings'],2)?></td><?php if(primary()):?><td><?=e($r['creator'])?></td><?php endif;?><?php if(can_manage()):?><td><a class="btn btn-sm btn-outline-primary" href="?edit=<?=$r['id']?>">Edit</a><form method="post" class="d-inline confirm"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn btn-sm btn-outline-danger">Delete</button></form></td><?php endif;?></tr><?php endforeach;?></tbody></table></div></div></div></div>
<?php include 'footer.php'; ?>
